import express from "express";
import cors from "cors";
import admin from "firebase-admin";

const app = express();
app.use(cors({origin: process.env.ALLOWED_ORIGIN || false}));
app.use(express.json({limit:"32kb"}));

if (!process.env.FIREBASE_SERVICE_ACCOUNT_JSON) {
  console.error("Set FIREBASE_SERVICE_ACCOUNT_JSON in the server environment.");
  process.exit(1);
}
const serviceAccount = JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT_JSON);
admin.initializeApp({credential:admin.credential.cert(serviceAccount)});
const db = admin.firestore();

async function requireUser(req,res,next){
  try{
    const header=req.headers.authorization||"";
    if(!header.startsWith("Bearer ")) return res.status(401).json({error:"Authentication required"});
    req.user=await admin.auth().verifyIdToken(header.slice(7));
    next();
  }catch{return res.status(401).json({error:"Invalid authentication token"});}
}
async function requireAdmin(req,res,next){
  if(req.user.admin!==true) return res.status(403).json({error:"Admin only"});
  next();
}
app.get("/health",(_req,res)=>res.json({ok:true,service:"BIDZZ CHAT API"}));
app.post("/reports",requireUser,async(req,res)=>{
  const message=String(req.body?.message||"").trim();
  if(!message||message.length>2000) return res.status(400).json({error:"Invalid report"});
  const ref=await db.collection("reports").add({
    reporterId:req.user.uid,message,status:"open",createdAt:admin.firestore.FieldValue.serverTimestamp()
  });
  res.status(201).json({id:ref.id,status:"received"});
});
app.get("/admin/reports",requireUser,requireAdmin,async(_req,res)=>{
  const snap=await db.collection("reports").orderBy("createdAt","desc").limit(100).get();
  res.json(snap.docs.map(d=>({id:d.id,...d.data()})));
});
app.patch("/admin/reports/:id",requireUser,requireAdmin,async(req,res)=>{
  const status=["open","reviewing","resolved","rejected"].includes(req.body?.status)?req.body.status:null;
  if(!status)return res.status(400).json({error:"Invalid status"});
  await db.collection("reports").doc(req.params.id).update({status,reviewedAt:admin.firestore.FieldValue.serverTimestamp()});
  res.json({ok:true});
});
const port=process.env.PORT||8080;
app.listen(port,()=>console.log(`BIDZZ CHAT API listening on ${port}`));
