# BIDZZ CHAT — Panduan instalasi

## 1. Yang sudah tersedia
- Antarmuka responsif tema gelap/hijau.
- Daftar/masuk menggunakan email dan password Firebase.
- Profil dasar pengguna.
- Pencarian pengguna berdasarkan email.
- Chat pribadi dan pesan real-time Firestore.
- Lampiran gambar/video/PDF/DOC/DOCX (maksimal 10 MB).
- Form laporan pengguna.
- PWA manifest dan service worker.
- Kerangka backend Node.js untuk health check dan moderasi laporan.
- Workflow GitHub Actions untuk membuat APK debug.

## 2. Siapkan Firebase (wajib)
1. Buka https://console.firebase.google.com/ dan buat project `BIDZZ CHAT`.
2. Tambahkan aplikasi Web dan salin konfigurasi Firebase.
3. Buka `src/firebase.js`, ganti seluruh nilai `GANTI_...` dengan konfigurasi project.
4. Authentication > Sign-in method: aktifkan Email/Password.
5. Firestore Database: buat database.
6. Storage: aktifkan Cloud Storage.
7. Pada Firestore > Rules, salin isi `firestore.rules`, lalu Publish.
8. Pada Storage > Rules, salin isi `storage.rules`, lalu Publish.
9. Authentication > Settings > Authorized domains: tambahkan domain hosting yang digunakan.

Jangan pernah menaruh Firebase Admin service account/private key di frontend. Firebase Web API config bukan pengganti aturan keamanan; aturan Firestore dan Storage tetap wajib dipasang.

## 3. Jalankan di komputer (opsional)
Pasang Node.js 20 atau lebih baru, lalu:
```bash
npm install
npm run dev
```
Buka alamat lokal yang ditampilkan Vite. Untuk produksi:
```bash
npm run build
```
Upload folder `dist` ke hosting HTTPS seperti Firebase Hosting.

## 4. Cara membuat APK hanya dengan HP Android
Metode yang disediakan adalah GitHub Actions (build di cloud).

1. Buat akun GitHub dan repository baru bernama `bidzz-chat`.
2. Upload seluruh isi folder proyek ini ke repository. Pastikan file `.github/workflows/android-apk.yml` ikut ter-upload.
3. Pastikan konfigurasi Firebase pada `src/firebase.js` sudah benar sebelum build.
4. Buka repository GitHub > tab **Actions**.
5. Pilih workflow **Build BIDZZ CHAT Android APK**.
6. Tekan **Run workflow** dan tunggu sampai status selesai.
7. Buka hasil workflow yang sukses, cari bagian **Artifacts**.
8. Unduh `BIDZZ-CHAT-debug-apk` lalu ekstrak ZIP artifact.
9. Buka `app-debug.apk` di Android dan izinkan instalasi dari sumber tersebut bila Android memintanya.

APK debug cocok untuk pengujian pribadi. Untuk distribusi publik, buat APK/AAB release yang ditandatangani dengan keystore milik sendiri dan simpan keystore serta password secara rahasia. Jangan bagikan file debug sebagai aplikasi resmi.

## 5. Menjalankan backend Node.js
Backend opsional ini digunakan untuk endpoint moderasi laporan. Deploy `server/` ke layanan Node.js yang mendukung environment variables.
- `FIREBASE_SERVICE_ACCOUNT_JSON`: isi JSON service account Firebase sebagai secret environment variable.
- `ALLOWED_ORIGIN`: domain frontend yang diizinkan.
- `PORT`: opsional, umumnya disediakan hosting.

Jangan commit file service account ke GitHub. Berikan custom claim `admin: true` hanya kepada akun admin tepercaya melalui proses Admin SDK yang aman. Endpoint admin memeriksa custom claim tersebut.

## 6. Batasan versi awal — baca sebelum dipakai
Ini adalah starter project/MVP, bukan aplikasi produksi setara WhatsApp.
- Login yang aktif saat ini adalah email/password. Login nomor HP perlu diaktifkan dan diuji terpisah dengan Firebase Phone Auth dan reCAPTCHA.
- Chat pribadi dan lampiran dasar sudah dibuat. Grup, status 24 jam, voice note, read receipts lengkap, backup, enkripsi end-to-end, push notification FCM, dan panggilan WebRTC belum diimplementasikan.
- Panggilan suara/video memerlukan signaling server/Firestore signaling, konfigurasi STUN/TURN, izin kamera/mikrofon, dan pengujian lintas jaringan.
- Notifikasi browser/PWA dan notifikasi native Android memerlukan konfigurasi FCM tambahan.
- Jangan gunakan untuk menyimpan informasi sangat sensitif sebelum audit keamanan, privasi, dan pengujian dilakukan.
- Firebase dan hosting dapat memerlukan billing sesuai pemakaian. Aktifkan budget alert dan jangan mengaktifkan layanan berbayar tanpa persetujuan pemilik akun/wali.

## 7. Checklist sebelum rilis
- [ ] Ganti Firebase config.
- [ ] Publish Firestore & Storage rules.
- [ ] Uji daftar, login, logout.
- [ ] Uji chat dua akun berbeda.
- [ ] Uji unggah dan akses lampiran.
- [ ] Uji aturan akses dengan akun yang bukan anggota chat.
- [ ] Siapkan kebijakan privasi dan mekanisme hapus akun/data.
- [ ] Audit keamanan dan buat release signing sebelum distribusi.
