import "./style.css";
import { auth, db, storage } from "./firebase.js";
import {
  createUserWithEmailAndPassword, signInWithEmailAndPassword,
  signOut, onAuthStateChanged, updateProfile
} from "firebase/auth";
import {
  collection, addDoc, query, where, orderBy, onSnapshot, doc,
  setDoc, getDoc, getDocs, serverTimestamp, updateDoc, arrayUnion
} from "firebase/firestore";
import { ref, uploadBytes, getDownloadURL } from "firebase/storage";

const screen = document.querySelector("#screen");
const nav = document.querySelector("#bottomNav");
const logoutBtn = document.querySelector("#logoutBtn");
let currentUser = null, activeTab = "chats", stopChats = null, stopMessages = null, activeChat = null;

const esc = (s="") => String(s).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const initials = (s="B") => s.trim().slice(0,1).toUpperCase();

function authView() {
  nav.classList.add("hidden"); logoutBtn.classList.add("hidden");
  screen.innerHTML = `
    <section class="auth-wrap">
      <div class="hero-logo">B</div><p class="eyebrow">PRIVATE MESSAGING</p>
      <h1>Selamat datang di <em>BIDZZ CHAT</em></h1>
      <p class="muted">Terhubung dengan teman, kapan saja.</p>
      <div class="panel">
        <div class="switch"><button id="loginMode" class="selected">Masuk</button><button id="registerMode">Daftar</button></div>
        <form id="authForm">
          <label>Nama pengguna <input id="displayName" placeholder="Nama kamu" autocomplete="name" /></label>
          <label>Email <input id="email" type="email" required placeholder="nama@email.com" autocomplete="email" /></label>
          <label>Password <input id="password" type="password" required minlength="6" placeholder="Minimal 6 karakter" autocomplete="current-password" /></label>
          <button class="primary full" type="submit" id="authSubmit">Masuk</button>
          <p id="authError" class="error"></p>
        </form>
      </div>
      <p class="tiny muted">Gunakan akun milikmu sendiri. Jangan bagikan password atau kode verifikasi.</p>
    </section>`;
  let mode = "login";
  const nameField = document.querySelector("#displayName");
  const setMode = m => {
    mode=m; nameField.parentElement.classList.toggle("hidden",m==="login");
    document.querySelector("#loginMode").classList.toggle("selected",m==="login");
    document.querySelector("#registerMode").classList.toggle("selected",m==="register");
    document.querySelector("#authSubmit").textContent=m==="login"?"Masuk":"Buat akun";
    document.querySelector("#password").autocomplete=m==="login"?"current-password":"new-password";
  };
  setMode("login");
  document.querySelector("#loginMode").onclick=()=>setMode("login");
  document.querySelector("#registerMode").onclick=()=>setMode("register");
  document.querySelector("#authForm").onsubmit=async e=>{
    e.preventDefault();
    const btn=document.querySelector("#authSubmit"), err=document.querySelector("#authError");
    btn.disabled=true; btn.textContent="Memproses…"; err.textContent="";
    try {
      const email=document.querySelector("#email").value.trim();
      const password=document.querySelector("#password").value;
      if(mode==="register"){
        const name=nameField.value.trim();
        if(!name) throw new Error("Isi nama pengguna.");
        const cred=await createUserWithEmailAndPassword(auth,email,password);
        await updateProfile(cred.user,{displayName:name});
        await setDoc(doc(db,"users",cred.user.uid),{
          uid:cred.user.uid, displayName:name, email, photoURL:"",
          createdAt:serverTimestamp(), about:"Hai! Saya menggunakan BIDZZ CHAT."
        });
      } else await signInWithEmailAndPassword(auth,email,password);
    } catch(ex){err.textContent=humanError(ex);}
    finally {btn.disabled=false;btn.textContent=mode==="login"?"Masuk":"Buat akun";}
  };
}

function humanError(e){
  const code=e?.code||"";
  const map={
    "auth/email-already-in-use":"Email sudah digunakan.",
    "auth/invalid-email":"Format email tidak valid.",
    "auth/weak-password":"Password minimal 6 karakter.",
    "auth/invalid-credential":"Email atau password salah.",
    "auth/network-request-failed":"Periksa koneksi internet.",
    "permission-denied":"Akses ditolak aturan keamanan Firebase."
  };
  return map[code]||e.message||"Terjadi kesalahan.";
}
function shell(title,body){
  screen.innerHTML=`<section class="page"><div class="page-heading"><div><p class="eyebrow">BIDZZ CHAT</p><h2>${title}</h2></div></div>${body}</section>`;
}
function setTab(tab){
  activeTab=tab; activeChat=null;
  if(stopMessages){stopMessages();stopMessages=null;}
  document.querySelectorAll("[data-tab]").forEach(b=>b.classList.toggle("active",b.dataset.tab===tab));
  if(tab==="chats") showChats();
  if(tab==="contacts") showContacts();
  if(tab==="profile") showProfile();
}
function showChats(){
  shell("Pesan",`<div class="toolbar"><input id="chatSearch" placeholder="Cari percakapan…" /><button id="newChat" class="primary">＋ Chat</button></div><div id="chatList" class="list"><div class="empty">Memuat percakapan…</div></div>`);
  document.querySelector("#newChat").onclick=()=>showContacts();
  const q=query(collection(db,"chats"),where("members","array-contains",currentUser.uid));
  if(stopChats)stopChats();
  stopChats=onSnapshot(q,snap=>{
    const el=document.querySelector("#chatList"); if(!el)return;
    const items=snap.docs.map(d=>({id:d.id,...d.data()}));
    el.innerHTML=items.length?items.map(c=>{
      const other=(c.memberNames||[]).find(x=>x.uid!==currentUser.uid);
      return `<button class="chat-row" data-id="${esc(c.id)}"><span class="avatar">${esc(initials(other?.name||"G"))}</span><span class="chat-info"><b>${esc(other?.name||c.title||"Grup")}</b><small>${esc(c.lastMessage||"Mulai percakapan")}</small></span><span class="chevron">›</span></button>`;
    }).join(""):`<div class="empty">Belum ada chat. Tekan <b>＋ Chat</b> untuk mencari teman.</div>`;
    el.querySelectorAll("[data-id]").forEach(b=>b.onclick=()=>openChat(b.dataset.id));
    document.querySelector("#chatSearch")?.addEventListener("input",e=>{
      const term=e.target.value.toLowerCase();
      el.querySelectorAll(".chat-row").forEach(r=>r.hidden=!r.innerText.toLowerCase().includes(term));
    },{once:true});
  },e=>document.querySelector("#chatList").innerHTML=`<p class="error">${esc(humanError(e))}</p>`);
}
async function showContacts(){
  shell("Kontak",`<p class="muted">Cari teman menggunakan email yang mereka daftarkan.</p><div class="toolbar"><input id="contactEmail" type="email" placeholder="Email teman" /><button id="findUser" class="primary">Cari</button></div><div id="contactResult"></div>`);
  document.querySelector("#findUser").onclick=async()=>{
    const email=document.querySelector("#contactEmail").value.trim().toLowerCase();
    const out=document.querySelector("#contactResult"); out.innerHTML='<p class="muted">Mencari…</p>';
    if(!email){out.textContent="Masukkan email.";return;}
    try{
      const q=query(collection(db,"users"),where("email","==",email));
      const snap=await getDocs(q);
      const u=snap.docs.map(d=>d.data()).find(x=>x.uid!==currentUser.uid);
      if(!u){out.innerHTML='<div class="empty">Pengguna tidak ditemukan.</div>';return;}
      out.innerHTML=`<div class="contact-card"><span class="avatar">${esc(initials(u.displayName))}</span><div class="chat-info"><b>${esc(u.displayName)}</b><small>${esc(u.email)}</small></div><button id="startChat" class="primary">Pesan</button></div>`;
      document.querySelector("#startChat").onclick=()=>createChat(u);
    }catch(e){out.innerHTML=`<p class="error">${esc(humanError(e))}</p>`;}
  };
}
async function createChat(u){
  try{
    const q=query(collection(db,"chats"),where("members","array-contains",currentUser.uid));
    const snap=await getDocs(q);
    const existing=snap.docs.find(d=>(d.data().members||[]).includes(u.uid));
    if(existing){openChat(existing.id);return;}
    const names=[{uid:currentUser.uid,name:currentUser.displayName||"Saya"},{uid:u.uid,name:u.displayName||"Teman"}];
    const chat=await addDoc(collection(db,"chats"),{members:[currentUser.uid,u.uid],memberNames:names,createdAt:serverTimestamp(),lastMessage:""});
    openChat(chat.id);
  }catch(e){alert(humanError(e));}
}
async function openChat(chatId){
  activeChat=chatId;
  if(stopMessages)stopMessages();
  const chatSnap=await getDoc(doc(db,"chats",chatId));
  if(!chatSnap.exists())return;
  const c=chatSnap.data(), other=(c.memberNames||[]).find(x=>x.uid!==currentUser.uid);
  screen.innerHTML=`<section class="conversation"><header class="conversation-head"><button id="back" class="icon-btn">‹</button><span class="avatar small-avatar">${esc(initials(other?.name||"G"))}</span><div><b>${esc(other?.name||"Grup")}</b><small class="online-label">Percakapan</small></div></header><div id="messages" class="messages"><div class="empty">Memuat pesan…</div></div><form id="sendForm" class="composer"><label class="attach">＋<input id="fileInput" type="file" accept="image/*,video/*,.pdf,.doc,.docx" hidden /></label><input id="messageInput" placeholder="Tulis pesan…" autocomplete="off" /><button class="send-btn" type="submit">➤</button></form><p id="sendError" class="error composer-error"></p></section>`;
  document.querySelector("#back").onclick=()=>setTab("chats");
  const msgQ=query(collection(db,"chats",chatId,"messages"),orderBy("createdAt","asc"));
  stopMessages=onSnapshot(msgQ,snap=>{
    const box=document.querySelector("#messages"); if(!box)return;
    box.innerHTML=snap.docs.map(d=>{
      const m=d.data(), mine=m.senderId===currentUser.uid;
      return `<div class="bubble-wrap ${mine?"mine":""}"><div class="bubble">${m.fileURL?`<a href="${esc(m.fileURL)}" target="_blank" rel="noopener">📎 ${esc(m.fileName||"Lampiran")}</a>`:""}${m.text?`<div>${esc(m.text)}</div>`:""}<small>${m.createdAt?.toDate?m.createdAt.toDate().toLocaleTimeString("id-ID",{hour:"2-digit",minute:"2-digit"}):"Baru saja"} ${mine?"✓":""}</small></div></div>`;
    }).join("")||'<div class="empty">Belum ada pesan. Sapa temanmu!</div>';
    box.scrollTop=box.scrollHeight;
  },e=>document.querySelector("#messages").innerHTML=`<p class="error">${esc(humanError(e))}</p>`);
  document.querySelector("#sendForm").onsubmit=async e=>{
    e.preventDefault(); const input=document.querySelector("#messageInput"), text=input.value.trim();
    if(!text)return;
    input.value="";
    try{
      await addDoc(collection(db,"chats",chatId,"messages"),{senderId:currentUser.uid,text,createdAt:serverTimestamp(),readBy:[currentUser.uid]});
      await updateDoc(doc(db,"chats",chatId),{lastMessage:text,lastMessageAt:serverTimestamp()});
    }catch(ex){document.querySelector("#sendError").textContent=humanError(ex);input.value=text;}
  };
  document.querySelector("#fileInput").onchange=async e=>{
    const file=e.target.files[0]; if(!file)return;
    if(file.size>10*1024*1024){alert("Ukuran file maksimal 10 MB.");return;}
    try{
      const safeName=file.name.replace(/[^a-zA-Z0-9._-]/g,"_");
      const path=`chatUploads/${chatId}/${currentUser.uid}/${Date.now()}_${safeName}`;
      const storageRef=ref(storage,path); await uploadBytes(storageRef,file);
      const url=await getDownloadURL(storageRef);
      await addDoc(collection(db,"chats",chatId,"messages"),{senderId:currentUser.uid,text:"",fileURL:url,fileName:file.name,createdAt:serverTimestamp(),readBy:[currentUser.uid]});
      await updateDoc(doc(db,"chats",chatId),{lastMessage:"Lampiran",lastMessageAt:serverTimestamp()});
    }catch(ex){document.querySelector("#sendError").textContent=humanError(ex);}
    e.target.value="";
  };
}
async function showProfile(){
  const snap=await getDoc(doc(db,"users",currentUser.uid)), u=snap.data()||{};
  shell("Profil",`<div class="profile-card"><div class="profile-avatar">${esc(initials(currentUser.displayName||"B"))}</div><h3>${esc(currentUser.displayName||"Pengguna")}</h3><p class="muted">${esc(currentUser.email)}</p><p>${esc(u.about||"Hai! Saya menggunakan BIDZZ CHAT.")}</p></div><div class="settings-card"><p><b>Identitas akun</b></p><p class="muted">UID: <code>${esc(currentUser.uid)}</code></p><p class="muted">Email digunakan untuk mencari kontak pada versi awal.</p><button id="reportBtn" class="secondary full">Laporkan masalah</button></div>`);
  document.querySelector("#reportBtn").onclick=async()=>{
    const message=prompt("Jelaskan masalah yang ingin dilaporkan:");
    if(!message?.trim())return;
    try{await addDoc(collection(db,"reports"),{reporterId:currentUser.uid,message:message.trim(),createdAt:serverTimestamp(),status:"open"});alert("Laporan terkirim.");}
    catch(e){alert(humanError(e));}
  };
}
logoutBtn.onclick=()=>signOut(auth);
nav.querySelectorAll("[data-tab]").forEach(b=>b.onclick=()=>setTab(b.dataset.tab));
onAuthStateChanged(auth,user=>{
  currentUser=user;
  if(!user){if(stopChats)stopChats();if(stopMessages)stopMessages();authView();return;}
  nav.classList.remove("hidden");logoutBtn.classList.remove("hidden");setTab(activeTab);
});
if("serviceWorker" in navigator && location.protocol!=="file:") window.addEventListener("load",()=>navigator.serviceWorker.register("/sw.js").catch(()=>{}));
